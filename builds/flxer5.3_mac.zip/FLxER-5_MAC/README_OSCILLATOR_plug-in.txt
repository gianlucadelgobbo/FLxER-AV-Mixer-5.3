///////////////////////////////////////////////////
/                                                 /
/ XXXXX X     X   X xxxxx xxxx                    /
/ X     X      X X  x     x   x                   /
/ XXX   X       X   xxx   xxxx                    /
/ X     X      X X  x     x  x                    /
/ X     XXXXX X   X xxxxx x   x     OSCILLATOR    /
/                                                 /
///////////////////////////////////////////////////
.-.-.-.-.-:EN:-.-.-.-.-.

- Open Monitor Out

- Open FLxER in "multi monitor" mode

- Open Oscillator Plug-in

- Enjoy

How to install:
-copy the folder "Oscillator" and its content in your FLxER "plug-in" folder 
-copy the Oscillator_plug-in application in your FLxER folder at the same level of your FLxER application


How to use:
The interface has 7 control panels, one for each FLxER 
channel.
first select the wave form from FUNCTION combobox
set the amplitude of the wave; default is 50, max 100
set the speed with the button tap 
then choose the property or the properties you want to change 
according with the wave form
press the button "APPLY TO CH" to start the plug-in and 
you will see the results in monitor out


.-.-.-.-.-:IT:-.-.-.-.-.

- Apri Monitor Out

- Apri FLxER in "multi monitor" mode

- Apri Oscillator Plug-in

- Enjoy

Come Installare:
-copia la cartella "Oscillator" con il suo contenuto nella cartella "plug-in" di FLxER 
-copia l'applicazione Oscillator_plug-in nella cartella di FLxER allo stesso livello dell'applicazione FLxER

Guida:
L'interfaccia visualizza 7 pannelli di controllo, uno per ogni canale di FLxER.
Innanzi tutto selezionare la forma d'onda dalla tendina FUNCTION
impostare l'ampiezza dell'onda; di default � 50, max 100
impostare la velocit� con il tasto Tap
quindi scegliere la propriet� o le propriet� che si desidera modificare
premere il pulsante "Applica a CH" per avviare il plug-in
Il risultato sar� visibile sul monitor out

  