///////////////////////////////////////////////////
/                                                 /
/ XXXXX X     X   X xxxxx xxxx                    /
/ X     X      X X  x     x   x                   /
/ XXX   X       X   xxx   xxxx                    /
/ X     X      X X  x     x  x                    /
/ X     XXXXX X   X xxxxx x   x    REMOTE SERVER  /
/                                                 /
///////////////////////////////////////////////////

- Open Terminal

- surf the folders to the FLxER folder

- Run java -jar FLxERremoteServer.jar

- Run FLxER-5remoteOut

Commands

q	close the application
info	open connection list
ch	channels list